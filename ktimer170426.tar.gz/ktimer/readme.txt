1.解压到/usr/local/目录
2.安装服务
./ktimer insrtall
3.卸载服务
./ktimer remove
4.启动服务
./ktimer start
5.停止服务
./ktimer stop
6.重启服务
./ktimer restart
7.查看帮助
./ktimer help
8.修改配置
vi conf.ini
保存然后重启服务
9.删除进程
使用kill删除进程后,服务不会自动重启
使用kill -9删除进程后,服务会自动重启

